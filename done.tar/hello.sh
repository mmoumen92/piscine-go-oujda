#!/bin/bash
echo Hello mmoumen!